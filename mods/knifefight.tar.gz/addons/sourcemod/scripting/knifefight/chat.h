
new isColorMsg = false;
